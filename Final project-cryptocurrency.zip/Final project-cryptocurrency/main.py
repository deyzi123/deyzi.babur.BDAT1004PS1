import requests
import time
from pymongo import MongoClient


client = MongoClient("mongodb+srv://project10:Finalproject1@cluster0.kaf9tu0.mongodb.net/bitcoindb?ssl=true&ssl_cert_reqs=CERT_NONE")
db = client.get_database('bitcoindb')
records=db.binance_24

import sched, time
s = sched.scheduler(time.time, time.sleep)
def api(sc): 
    r=requests.get("https://cryptingup.com/api/markets")
    data = r.json()
    records.insert_one(data)
    sc.enter(86400, 1, api, (sc,))

s.enter(86400, 1, api, (s,))
s.run()
