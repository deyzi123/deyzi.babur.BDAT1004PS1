import requests
from flask import Flask,jsonify,request,render_template
from pymongo import MongoClient

app = Flask(__name__)
client = MongoClient("mongodb+srv://project10:Finalproject1@cluster0.kaf9tu0.mongodb.net/bitcoindb?ssl=true&ssl_cert_reqs=CERT_NONE")
db = client.get_database('bitcoindb')
records=db.binance_24
r=requests.get("https://cryptingup.com/api/markets")
USDT = []
BUSD = []
USDC = []

# if r.status_code==200:
data = records.find_one()
for i in range(len(data['markets'])):
    if data['markets'][i]['exchange_id'] == "BINANCE":
        sym = data['markets'][i]['symbol']
        temp = sym.split('-')
    if temp[1] == "USDT":
        USDT.append((temp[0],data['markets'][i]['price']))
    if temp[1] == "BUSD":
        BUSD.append((temp[0],data['markets'][i]['price']))
    if temp[1] == "USDC":
        USDC.append((temp[0],data['markets'][i]['price']))
USDT = set(tuple(element) for element in USDT)
BUSD = set(tuple(element) for element in BUSD)
USDC = set(tuple(element) for element in USDC)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/usdt')
def USDT_chart():
    USDTa = list(USDT)
    USDTb = []
    for i in range(len(USDTa)):
        if USDTa[i][1] > 500:
            USDTb.append([USDTa[i][0],USDTa[i][1]])
        if len(USDTb) >= 4:
            break
    size = len(USDTa)
    return render_template('USDT_chart.html',USDTa=USDTb,size=size)

@app.route('/usdc')
def USDC_chart():
    USDCa = list(USDC)
    return render_template('USDC_chart.html',USDCa=USDCa)

@app.route('/busd')
def BUSD_chart():
    BUSDa = list(BUSD)
    BUSDb = []
    for i in range(len(BUSDa)):
        if BUSDa[i][1] > 500:
            BUSDb.append([BUSDa[i][0],BUSDa[i][1]])
        if len(BUSDb) >= 4:
            break
    size = len(BUSDa)
    #BUSDa = list(BUSD)
    return render_template('BUSD_chart.html',BUSDa=BUSDb,size=size)

import sched, time
def api(): 
    r=requests.get("https://cryptingup.com/api/markets")
    data = r.json()
    records.insert_one(data)
    print(data)
# s.enter(86400, 1, api, (s,))
# s.run()
api()
if __name__=="__main__":
    app.run()


